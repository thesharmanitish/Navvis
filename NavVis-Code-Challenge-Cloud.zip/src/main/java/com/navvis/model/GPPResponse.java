package com.navvis.model;

public interface GPPResponse {

	
	
}


