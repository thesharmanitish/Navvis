package com.navvis.config;

public class Constant {

	public static final String HTTP_400 = "400";

}
